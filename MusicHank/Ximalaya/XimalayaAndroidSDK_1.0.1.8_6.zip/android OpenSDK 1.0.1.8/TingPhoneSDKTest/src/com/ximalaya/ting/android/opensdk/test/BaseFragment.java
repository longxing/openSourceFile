/**
 * BaseFragment.java
 * com.ximalaya.ting.android.opensdk.test
 *
 *
 *   ver     date      		author
 * ---------------------------------------
 *   		 2015-6-4 		chadwii
 *
 * Copyright (c) 2015, chadwii All Rights Reserved.
*/

package com.ximalaya.ting.android.opensdk.test;

import android.support.v4.app.Fragment;

/**
 * ClassName:BaseFragment
 *
 * @author   chadwii
 * @version  
 * @since    Ver 1.1
 * @Date	 2015-6-4		上午9:55:06
 *
 * @see 	 
 */
public class BaseFragment extends Fragment
{

	public void refresh()
	{
	}

}

