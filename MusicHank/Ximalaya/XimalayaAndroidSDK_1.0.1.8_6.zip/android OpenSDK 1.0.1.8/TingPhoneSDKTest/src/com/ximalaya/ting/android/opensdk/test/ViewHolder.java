/**
 * ViewHolder.java
 * com.ximalaya.ting.android.opensdk.test
 *
 * Function： TODO 
 *
 *   ver     date      		author
 * ---------------------------------------
 *   		 2015-6-4 		chadwii
 *
 * Copyright (c) 2015, chadwii All Rights Reserved.
*/

package com.ximalaya.ting.android.opensdk.test;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * ClassName:ViewHolder
 * Function: TODO ADD FUNCTION
 * Reason:	 TODO ADD REASON
 *
 * @author   chadwii
 * @version  
 * @since    Ver 1.1
 * @Date	 2015-6-4		下午3:17:04
 *
 * @see 	 
 */
public class ViewHolder
{
	public ViewGroup content;
	public ImageView cover;
	public TextView title;
	public TextView intro;
	public TextView status;
}
