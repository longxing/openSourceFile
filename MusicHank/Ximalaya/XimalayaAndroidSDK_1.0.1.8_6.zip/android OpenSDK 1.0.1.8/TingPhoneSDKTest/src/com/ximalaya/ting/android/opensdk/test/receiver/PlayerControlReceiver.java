/**
 * PlayerControlReceiver.java
 * com.ximalaya.ting.android.opensdk.test
 *
 * Function： TODO 
 *
 *   ver     date      		author
 * ---------------------------------------
 *   		 2015-7-9 		chadwii
 *
 * Copyright (c) 2015, chadwii All Rights Reserved.
*/

package com.ximalaya.ting.android.opensdk.test.receiver;

import com.ximalaya.ting.android.opensdk.player.XmPlayerManager;
import com.ximalaya.ting.android.opensdk.test.constants.Constants;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * ClassName:PlayerControlReceiver
 * Function: TODO ADD FUNCTION
 * Reason:	 TODO ADD REASON
 *
 * @author   chadwii
 * @version  
 * @since    Ver 1.1
 * @Date	 2015-7-9		上午11:26:20
 *
 * @see 	 
 */
public class PlayerControlReceiver extends BroadcastReceiver
{

	@Override
	public void onReceive(Context context, Intent intent)
	{
		XmPlayerManager manager = XmPlayerManager.getInstance(context);
		String action = intent.getAction();
		if (Constants.ACTION_CONTROL_PLAY_PAUSE.equals(action))
		{
			if (manager.isPlaying())
			{
				manager.pause();
			}
			else
			{
				manager.play();
			}
		}
		else if (Constants.ACTION_CONTROL_PLAY_NEXT.equals(action))
		{
			manager.playNext();
		}
	}

}

