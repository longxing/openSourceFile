/**
 * Constants.java
 * com.ximalaya.ting.android.opensdk.test.constants
 *
 * Function： TODO 
 *
 *   ver     date      		author
 * ---------------------------------------
 *   		 2015-7-9 		chadwii
 *
 * Copyright (c) 2015, chadwii All Rights Reserved.
*/

package com.ximalaya.ting.android.opensdk.test.constants;
/**
 * ClassName:Constants
 * Function: TODO ADD FUNCTION
 * Reason:	 TODO ADD REASON
 *
 * @author   chadwii
 * @version  
 * @since    Ver 1.1
 * @Date	 2015-7-9		上午11:07:43
 *
 * @see 	 
 */
public class Constants
{
	public static final String ACTION_CONTROL_PLAY_PAUSE = "com.ximalaya.ting.android.opensdk.test.constants.ACTION_CONTROL_PLAY_PAUSE";
	public static final String ACTION_CONTROL_PLAY_PRE = "com.ximalaya.ting.android.opensdk.test.constants.ACTION_CONTROL_PLAY_PRE";
	public static final String ACTION_CONTROL_PLAY_NEXT = "com.ximalaya.ting.android.opensdk.test.constants.ACTION_CONTROL_PLAY_NEXT";
}

